export const colors = ['red', 'blue', 'green', 'yellow', 'white', 'black'];
