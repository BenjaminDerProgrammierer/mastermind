import './style.css';
import { colors } from './settings';
import './helpers';
import { dialog } from './helpers';

// TODO: Generate random solution sequence

// TODO: Build the game board
//        - rows
//          - pegs
//          - result cells
//        - color picker
//          - pegs
//          - buttons

// TODO: Game logic
//        - select peg, next peg, previous peg, submit row
//        - win / loose with dialog

// TODO: Keybinds
