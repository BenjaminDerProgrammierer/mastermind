// Status 2025-06-27; Felix, Maximilian, Philipp
import './style.css';
import { colors } from './settings';
import './helpers';
import { dialog } from './helpers';

const game = document.getElementById('game') as HTMLDivElement;

const pegs: HTMLDivElement[][] = [];
const results: HTMLDivElement[][] = [];

let currentRow = 11;
let currentCell = 0;

// Generate random solution sequence
const solution: string[] = [];

for (let i = 0; i < 4; i++) {
  let numColors = colors.length;
  let randomNumber = Math.floor(Math.random() * numColors);
  let randomColor = colors[randomNumber];
  solution.push(randomColor);
}

dialog.open('Farben', colors.join(', ') + ' Lösung: ' + solution.join(', '));

// Build the game board
const rows: HTMLDivElement[] = [];

for (let i = 0; i < 12; i++) {
  const row = document.createElement('div');
  row.classList.add('row', 'pegs');
  rows.push(row);

  // 4 game pegs
  const rowPegs: HTMLDivElement[] = [];
  for (let j = 0; j < 4; j++) {
    const rowPeg = document.createElement('div');
    rowPeg.classList.add('peg');
    rowPegs.push(rowPeg);
    row.appendChild(rowPeg);
  }
  pegs.push(rowPegs);

  // 4 result cells
  const resultCell = document.createElement('div');
  resultCell.classList.add('results');

  const rowResults: HTMLDivElement[] = [];
  for (let j = 0; j < 4; j++) {
    const rowResult = document.createElement('div');
    rowResult.classList.add('result', 'white');
    rowResults.push(rowResult);
    resultCell.appendChild(rowResult);
  }
  results.push(rowResults);
  row.appendChild(resultCell);

  game.appendChild(row);
}

const colorPicker = document.createElement('div');
colorPicker.classList.add('pegs', 'color-picker');
// colors
for (const color of colors) {
  const colorCell = document.createElement('div');
  colorCell.classList.add('peg', color);
  // TODO: Click-Aktion
  colorPicker.appendChild(colorCell);
}

// buttons
const back = document.createElement('div');
back.classList.add('button');
back.innerHTML = '<span>⬅️</span>';
// TODO: Click-Aktion
colorPicker.appendChild(back);

const next = document.createElement('div');
next.classList.add('button');
next.innerHTML = '<span>☑️</span>';
// TODO: Click-Aktion
colorPicker.appendChild(next);

document.getElementById('app')!.appendChild(colorPicker);

function updateOffset() {
  colorPicker.style.top = rows[currentRow].offsetTop + 2 + 'px';
  colorPicker.style.left =
    rows[currentRow].offsetLeft + rows[currentRow].offsetWidth + 10 + 'px';
}
window.onresize = updateOffset;
updateOffset();

// TODO: Game logic
//        - select peg, next peg, previous peg, submit row
//        - win / loose with dialog

// TODO: Keybinds
